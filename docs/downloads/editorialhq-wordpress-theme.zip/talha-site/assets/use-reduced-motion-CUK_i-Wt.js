import{a as o}from"./icons-Dv4y9ep4.js";import{W as t,X as r,Y as s}from"./app-D8HnR_yM.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
