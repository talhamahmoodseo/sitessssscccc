import{a as o}from"./icons-1H5MU307.js";import{P as t,Q as r,R as s}from"./app-Cs1N48Ub.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
