import{a as o}from"./icons-DwdE5aM8.js";import{P as t,Q as r,R as s}from"./app-BWgyVT1y.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
