import{a as o}from"./icons-Bw16MUec.js";import{W as t,X as r,Y as s}from"./app-DUcRY1QV.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
