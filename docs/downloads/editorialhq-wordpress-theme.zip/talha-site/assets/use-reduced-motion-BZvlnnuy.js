import{a as o}from"./icons-B8uqLsuy.js";import{P as t,Q as r,R as s}from"./app-zWm3d1ya.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
