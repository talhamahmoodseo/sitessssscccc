import{a as o}from"./icons-Cj2_zAT8.js";import{W as t,X as r,Y as s}from"./app-5kGUuUmW.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
