import{a as o}from"./icons-TFhymhH4.js";import{W as t,X as r,Y as s}from"./app-BYIhn2ih.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
