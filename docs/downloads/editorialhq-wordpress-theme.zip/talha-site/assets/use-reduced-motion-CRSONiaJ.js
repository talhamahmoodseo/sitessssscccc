import{a as o}from"./icons-DwdE5aM8.js";import{W as t,X as r,Y as s}from"./app-CoPic5Bo.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
