import{a as o}from"./icons-D9VDBrpe.js";import{P as t,Q as r,R as s}from"./app-CCvown1g.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
