import{a as o}from"./icons-BllPk_tw.js";import{P as t,Q as r,R as s}from"./app-CZsH49GO.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
